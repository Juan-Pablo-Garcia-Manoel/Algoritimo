class Atleta{
    private string nome;
    public void setNome(string novoNome){nome = novoNome;}
    public string getNome(){return nome;}
    
    private int idade;
    public void setIdade(int novaIdade){idade = novaIdade;}
    public int getIdade(){ return idade;}

    private double peso;
    public void setPeso(double novoPeso){peso = novoPeso;}
    public double getPeso(){ return peso;}

    private double altura;
    public void setAltura(double novaAltura){altura = novaAltura;}
    public double getAltura(){return altura;}
}